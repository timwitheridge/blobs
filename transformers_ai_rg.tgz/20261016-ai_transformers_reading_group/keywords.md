# Keywords
- **Polysemanticity**: Weights have different effects in different contexts. 
- **Monosemanticity**: We want to rewrite / re-express weights to have a single, interpretable meaning in all contexts. 
- **Superposition**: Polysemanticity arises because of nonlinear interactions / combinations with other weights. 
- **Context-dependency**: The effect of weights depends on context (inputs). 

