_An ambitious hope for mechanistic interpretability_

Q: What is the meaning of 'mechanistic' in 'mechanistic interpretability'? Why not just 'interpretability'?

A:
Culturally, the word describes a distinct sub-community within AI research that originated around 2020 (heavily influenced by researcher Chris Olah and labs like Anthropic). In this context, "mechanistic" serves as a flag for research aimed at AI safety and alignment. The goal here is to carefully audit models to detect unaligned behaviors like deception, sycophancy, or hidden biases before they become dangerous.

*So MI has strong connotation for AI safety and alignment.*

---

## 2 measures of weight importance
1. **Effectiveness**: Magnitude of its effect on the model's outputs.
	- We measure it as a second-order estimate of the KL divergence between the model's outputs with and without the weight (using the Fisher metric)
	- Effectiveness measures which of a weight's effects survive interference from every other path. 
2. **Helpfulness**: Magnitude and sign of its effect on the loss. 
	- The average change in loss when the weight is ablated from the forward pass. 
	- If the loss rises when we remove a weight, the weight is helping the model toward the right answer; if the loss falls, it is harmful. 

Relationship: A weight has to be effective to have helpfulness, but there's no inherent connection between a weight's effectiveness and the sign of its helpfulness. 

Motivation:
- Identify interference weights
- Simplify complex models (Q: could this be described as regularisation?)

2 kinds of superposition:
- Feature superposition: How features are arranged in a lower-dimensional representation. 
- Weight superposition: How weights between 2 sets of features in superposition are also put into superposition. 

## 3 main findings
1. Helpful and harmful weights are scattered across the entire range of virtual weight magnitudes. 
2. Ineffective virtual weights are abundant and can be easily removed. 
3. The number of helpful virtual weights in this basis still appears large. 

---

Q: What are the problems / barriers the authors have highlighted?
- Helpfulness is better than effectiveness because it directly tells you the effect of a weight on the loss. 
    - My Q: They are computing Effectiveness and Helpfulness over the entire dateset. Could there be some subsets of the training set that the model would be Effective / Helpful for, and this needs to be considered?
- Helpfulness is expensive to compute though. 

This sentence here is problematic to me:
_It is difficult to say which level of helpfulness mass is a better guide, particularly when we also expect nonlinear effects from removing multiple weights together._

I suppose the sparse representation mitigates, but does not entirely eliminate, the nonlinearity / dependency. 

...

- I would say the value of the paper is that E and H are a useful way of thinking about the importance of a weight rather than naively the size of the weight. 
- It is a novel approach to attempt to interpret model weights. 
- There seem to be big practical challenges in utilising E and H for model pruning for anything more sophisticated than toy models, let alone foundation models. 

