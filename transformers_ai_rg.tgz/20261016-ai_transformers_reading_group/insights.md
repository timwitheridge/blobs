Q: Ignoring softmax, is causal masking a linear operation?
A:
Causal masking is an affine, not linear operation. 

---

Softmax is not layer normalisation. 

---

JumpRELU is RELU with a discontinuity at the origin. 

---

https://transformer-circuits.pub/2021/framework/index.html

