Transformers & AI Reading Group  
Characterizing interference weights in a tiny language model  
Friday, 16th October 2026  
Tim Witheridge

# Introduction
*Providing a context-independent (or **global**) description of its computation.*

- Mechanistic intepretability: We want a context-independent (or global) description of its computation. 
- Models leverage superposition for representation capacity. 
- 2 challenges posed by superposition to directly reading weights:
    1. Basis of neurons is polysemantic. Polysemanticity can be addressed using **dictionary learning** and **virtual weights**, but
    2. Virtual weights also prone to superposition / polysemanticity due to low-dimensional projections. 
- Weight superposition has been posulated to result in **interference weights**.  
- If we could identify interference weights accurately, we could hope to remove them and recover a sparse model. 

*Exercise: What is the simplest example demonstrating polysemanticity of neural network weights?*

## What has been done previously?
- Previously identified interference weights in a simple toy model based around a single low-dimensional projection
- Found that a weight's effect on the loss predicts whether it belongs to the circuit the model was trained to implement.
- Coactivation statistics can downweight connections between unrelated feature pairs;
- lacked a trained transformer in which we could point at specific interference weights, characterize them, and connect them to performance.

## New stuff is this paper doing
Here, we:
- Train a one-layer transformer,
- decompose it into the virtual weights between its tokens, positions, features, and logits, and
- study how those weights combine to produce the model's behavior on the data distribution

_While prior work has characterized the emergence and identifiability of interference weights in a toy setting, where a neural network is trained to emulate a larger, sparse, ground-truth model, this note is the first place, to our knowledge, that an interference weight like this one has been demonstrated inside a trained transformer by measuring their effect on the training loss._

Approach of the paper:
- Demonstrate the problem on a 'real' but simplified transformer
- Derive a vastly simplified version of this model weights that are less polysemantic (more monosemantic)
    - Monosemanticity encouraged via sparsity
- Use this simplified model to attempt to characterise interference weights using 2 measures of importance: Effectiveness and helpfulness. 
- Comment on the use of these 2 measures to derive a sparser, more interpretable model. 

# A motivating example
_Our one-layer transformer 3 has a simple decomposition we use to illustrate the basic problem.  The logit for any candidate token is a sum of contributions along three paths: the direct path from the current input (combining the input token and a position embedding), the attention path, and the MLP path._

**Exercise: Demonstrate this decomposition in Python.**  
**Exercise: Reproduce these results with a toy model and dataset.**

_Ineffective or harmful weights are not valid lessons that the model has learned; they are interference weights that the model carries alongside its actual circuits._

# The virtual weight model
Q: Why do you need the transcoder?
A: To encourage sparsity in the VW model. 

_tokens, positions, transcoder features, and output logits_
That is, the VW model maps tokens, positions and TC features to output logits. 

axis of size $d_{v'} = 5120$
5120 = 4096 + 1024

Key thing here is to refer to the diagram in the appendix. 

**Exercise: Build the VW model in Python.**

_The VW model exactly reproduces the forward pass of the original transformer with an error term for the transcoder and appropriate composition of these matrices._

**Exercise: Ignore the decoder and implement the original transformer using this matrix decomposition, and proves that it gives the same outputs.**

_Materializing all six families inflates the parameter count from 2.9M to roughly 331M, about 100×, since each pair of endpoints now carries its own explicit weight rather than sharing the residual stream._

**Exercise: Derive these numbers.**

2.9M original transformer:
_The transformer we study is a one-layer, decoder-only transformer with residual width [TODO] = 64, a width-1024 MLP with ReLU activation, a 4,096-token vocabulary, and a 1,024-token context window, totaling ≈2.9M parameters (≈0.79M excluding the embedding and unembedding matrices). The model contains no normalization layers and no bias terms anywhere._

```
d_voc = 4096
d_emb = 256
d_mlp = 1024

n_head = 4
d_head = d_emb / n_head # 64
d_ctx = 1024

# Embedding
nw_emb = d_voc * d_emb

# Q, K, V
nw_q = d_emb * d_emb
nw_k = d_emb * d_emb
nw_v = d_emb * d_emb
nw_o = d_emb * d_emb

# MLP
nw_mlp = d_emb * d_mlp * 2

# Unembedding
nw_unemb = d_voc * d_emb

# Total
nw_emb + nw_q + nw_k + nw_v + nw_o + nw_mlp + nw_unemb
# 2883584 ~2.9M

# Excluding embedding / unembedding
nw_q + nw_k + nw_v + nw_o + nw_mlp
# 786432 ~0.79M
```

331M VW model:
```
d_voci = 5120
d_voco = 4096
d_sae = 4096
nw_tl = d_voci * d_voco
nw_qk = d_voci * d_voci * 4
nw_tol = d_voco * d_voci * 4
nw_tf = d_sae * d_voci
nw_tof = d_sae * d_voci * 4
nw_fl = d_sae * d_voco
nw_tl + nw_qk + nw_tol + nw_tf + nw_tof + nw_fl
331350016
```

# Effectiveness and helpfulness
$$
\text{fisher}(w) = \frac{1}{2}\mathbb{E}_{x~D}[Var_p(a)] = \frac{1}{2}\mathbb{E}_{x~D}[a^TFa]
$$
Where 
$$
F = diag(p) - pp^T
$$
is the Fisher information matrix of the softmax WRT the logits. 

_Helpfulness can be computed cheaply for weight families that target the logits (Appendix), but for the rest it is expensive._

**Exercise: Give a demo of computing effectiveness.**

# Effectiveness surfaces helpful weights but does not isolate them
4 examples:
1. Confirm that the confusing Tokens→Logit weight from "IN" was in fact interference and to show that effectiveness can filter interference weights from the most prominent effects.  
2. Sometimes the largest magnitude virtual weights are indeed helpful
3. The most Fisher-effective weights tend to be helpful but are sometimes harmful
4. Weight families which do not target the logits have lower Fisher-effectiveness than those that do, but these families still show the same qualitative patterns relating weight magnitude, effectiveness, and helpfulness.

## Example 1
TODO

## Example 2
TODO

## Example 3
TODO

## Example 4
TODO

# The model is still dense in this basis
_This costs approximately 0.01 nats at 70% sparsity (30% density) and under 0.1 nats at 85% sparsity (15% density)_

Still ~50M weights or 17x the size of the original transformer. 
```
>>> 331 * 0.15
49.65
>>> 50 / 2.9
17.24137931034483
```

_This performs far better than raw virtual weight magnitude for every density_

Yes, because the red line is stricly beneath the blue line. 

_At 1%, where the parameter count roughly matches the original transformer, the pruned model's performance is significantly compromised._  

Looks to be over 100% worse. 

_Across the sample, roughly half (47.6%) of all weights have positive mean helpfulness (with 12.7% dead), and even counting only those whose confidence interval excludes zero leaves tens of percent (see more details in the Appendix).  Since our VW model increases the overall number of parameters by two orders of magnitude, we're still left with tens of millions of weights to interpret for a single-layer model._  

Key idea here is that, unlike effectiveness, which we can't tell directly will help or hurt the loss if we remove it, we know directly from its helpfulness whether removing it will help or hurt the model. 

If it has positive helpfulness, it can't be removed without negatively affecting the loss, and should therefore be kept. 

From the random sample, half have positive helpfulness. So we can only use helpfulness to remove roughly a half. 

Now, you might ask - what if we consider those weights who are not only helpful but also 'large', i.e. we consider their size too (their 95% CI doesn't contain 0)? The finding is that this still leaves 10s of percent of weights. 

# Discussion
(Nice summary of the entire paper). 

_We find that large virtual weights are not guaranteed to be helpful or even effective._

_Sometimes the largest weights are the functional ones, as for the Chinese feature whose top weights predicts intuitive byte-prefixes, and sometimes the largest weight is interference that never influences the output._

_Sorting by effectiveness can help to highlight important weights and interpret the model's functional circuitry, even if it does not cleanly separate all helpful weights from the harmful ones._

_We were unable to reach a highly sparse and interpretable model using Fisher effectiveness as the filtering criterion, and we suspect, based on our helpfulness computations, that no saliency scheme will perform much better.  We think this says less about the potential for a sparse interpretation of this model than about the basis in which we study it.  We expressed our virtual weight model using the coordinates of tokens and features of this transformer, and the same model can be dense in one basis but sparse in another._

_Interference weights are one of the stranger implications of trained models approximating high-dimensional circuits through low-dimensional bottlenecks; despite significant optimization pressure, large, confident connections can actively harm the model's performance._

_We suspect that a similar model within a better basis may still provide further sparsity and interpretability._
- One of the more interesting statements in the paper. Q: How to find a good basis for a NN?

# Overall impressions of the paper
Q: If helpfulness were cheap to compute, would that solve all our problems?
A: Not really, unless it turned out that we 'got unlucky' with our sampling and it somehow turns out that most of the weights are unhelpful. Extremely unlikely though. 

...

What the authors have done:
- Taken the simplest possible transformer that can do something resembling the difficulty of a real-world task
- Simplified it so much (no layer norm or bias) that most of it (not all of it) can be expressed as linear maps
    - In the process, however, they blow up the number of weights 100x
- Demonstrated that their measures of importance (E and H) can be used to identify interference weights in this VW model
- Showed that E is powerful for weight pruning - unequivocally better than weight size alone

What they haven't done:
- After pruning say 85%, they are still left with a model with 17x the weights as the original
- They haven't done the actual pruning step and attempted to fully characterise / interpret all the weights / paths in the pruned model
- They built the VW model to try to encourange monosemanticity, but it is imperfect. I would say the validity of conclusions based on calculating E and H on the entire dataset is only as good as the monosemanticity of the weights of their VW model. 
- They don't make an attempt to quantify the extent to which they've achieved monosemanticity of weights on their VW model. Is the SAE sparse enough? How would they quantify it?

**The north star**: If you could
- Create a similar VW model for a 'real' model, e.g. a foundation model
- Compute E and H (expensive) for all weights in the VW model
- Use this to prune the model
- Demonstrate similar performance as the original model
- Then fully characterise all weights in the pruned model and thereby understand all circuits

That would be an enormous achievement. 

# My final thoughts
- You have heard it said that AI will create jobs as well as destroy them. It seems conceivable that software will be developed soon (if not already) designed to interpret these models, if not an entire industry devoted to mechanistic interpretability. 
- Imagine e.g. a B2B company with a SaaS platform that takes a specification (incl weights) of an AI company's foundation model, builds a VW model under the hood, and provides a tool for the AI company to interpret their model, identify interference weights, recommendations candidate weights for for weight pruning to create a sparser model and thereby reduce inference costs etc. 

